"""
Financial Document Intelligence System

A Tornado-based application for processing, analyzing and querying financial documents.
"""
 
__version__ = "1.0.0" 